import streamlit as st
import pandas as pd
import pyodbc
from database.dbcon import execute_stored_procedure, fetch_data

st.set_page_config(layout="wide")

def main():
    st.title("Daily Plan Report")

    st.markdown("""
    #### Report: Daily Plan  
    #### Month: -  
    #### Year: 2025  
    #### Plant: -
    """)

    # Date inputs side by side
    left_col, mid_col = st.columns(2)
    with left_col:
        date_from = st.date_input("Date From")
    with mid_col:
        date_to = st.date_input("Date To")

    submit = st.button("Submit")

    if submit:
        try:
            execute_stored_procedure('dbo.GenerateDailyLoad_Plan', [date_from, date_to])
            execute_stored_procedure('dbo.GenerateDailyLoad_Plan_000C', [date_from, date_to])
            execute_stored_procedure('dbo.GenerateDailyLoad_Plan_013', [date_from, date_to])
            execute_stored_procedure('dbo.GenerateDailyLoad_Plan_014C', [date_from, date_to])

        except Exception as e:
            st.error(f"Failed to execute stored procedure: {e}")

    # Fetch and display data
    try:
        df = fetch_data("SELECT * FROM iPAR_DailyLoad_Plan")
        df_000C = fetch_data("SELECT * FROM iPAR_DailyLoad_Plan_000C")
        df_014C = fetch_data("SELECT * FROM iPAR_DailyLoad_Plan_014C")
    except Exception as e:
        st.error(f"Failed to fetch data: {e}")
        return

    right_col, _ = st.columns([4, 1])
    with right_col:
        search_term = st.text_input("", placeholder="Search here...")
    
    if search_term:
        mask = df.apply(lambda row: row.astype(str).str.contains(search_term, case=False, na=False).any(), axis=1)
        df = df[mask]
        mask = df_000C.apply(lambda row: row.astype(str).str.contains(search_term, case=False, na=False).any(), axis=1)
        df_000C = df_000C[mask]
        mask = df_014C.apply(lambda row: row.astype(str).str.contains(search_term, case=False, na=False).any(), axis=1)
        df_014C = df_014C[mask]

    st.subheader("Set")
    st.dataframe(
        df,
        column_config={
            "Id": st.column_config.NumberColumn("Id", pinned=True),
            "Product_No": st.column_config.TextColumn("Product_No", pinned=True),
            "DCL": st.column_config.TextColumn("DCL", pinned=True),
            "LineCd": st.column_config.TextColumn("LineCd", pinned=True),
        },
        use_container_width=True,
        hide_index=True
    )

    # Display dataframe with pinned columns
    st.subheader("000C")
    st.dataframe(
        df_000C,
        column_config={
            "Id": st.column_config.NumberColumn("Id", pinned=True),
            "Product_No": st.column_config.TextColumn("Product_No", pinned=True),
            "DCL": st.column_config.TextColumn("DCL", pinned=True),
            "LineCd": st.column_config.TextColumn("LineCd", pinned=True),
        },
        use_container_width=True,
        hide_index=True
    )

    st.subheader("014C")
    st.dataframe(
        df_014C,
        column_config={
            "Id": st.column_config.NumberColumn("Id", pinned=True),
            "Product_No": st.column_config.TextColumn("Product_No", pinned=True),
            "DCL": st.column_config.TextColumn("DCL", pinned=True),
            "LineCd": st.column_config.TextColumn("LineCd", pinned=True),
        },
        use_container_width=True,
        hide_index=True
    )

if __name__ == "__main__":
    main()