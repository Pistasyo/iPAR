import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
from st_aggrid import AgGrid
from st_aggrid.shared import GridUpdateMode, DataReturnMode
from sqlalchemy import create_engine
import urllib
from database.dbcon import fetch_data

# ========== DATABASE CONNECTION ==========
server = r"172.17.225.13"
database = "iPAR"
username = "sa"
password = "s@p@33"

params = urllib.parse.quote_plus(
    f"DRIVER={{ODBC Driver 17 for SQL Server}};"
    f"SERVER={server};DATABASE={database};"
    f"UID={username};PWD={password};"
    "Trusted_Connection=no;"
)

x = fetch_data("SELECT CustomerLine FROM LineMaster")["CustomerLine"].tolist()

engine = create_engine(f"mssql+pyodbc:///?odbc_connect={params}")
st.set_page_config(layout="wide")
# ========== BASE TABLE STRUCTURE ==========
dates = [datetime(2025, 10, 1) + timedelta(days=i) for i in range(31)]

# lineName = [i for i in fetch_data("SELECT CustomerLine FROM LineMaster")]
def create_empty_table():
    """Creates the base structure for a new/cleared table."""
    data = {
        "Line Name Master": x,
        "Beginning Backlog 013": [None for i in x],
        "Beginning Backlog 014C": [None for i in x],
    }
    for d in dates:
        data[f"{d.date()} 013"] = [None for i in x]
        data[f"{d.date()} 014C"] = [None for i in x]
    return pd.DataFrame(data)

# Try to load existing data (for initial display only)
try:
    df = pd.read_sql("SELECT * FROM DailyReport_014C_013_End", engine)
    # st.success("✅ Loaded existing data from SQL Server.")
except Exception:
    # st.info("ℹ️ No existing data found — starting with a new blank table.")
    df = create_empty_table()

# ========== DEFINE AG-GRID STRUCTURE ==========
column_defs = [
    {
        "headerName": "Line Name Master",
        "field": "Line Name Master",
        "editable": False,
        "pinned": "left",
        "wrapText": True,
        "autoHeight": True,
        "autoSize": True,
    },
    {
        "headerName": "Ending Backlog",
        "pinned": "left",
        "children": [
            {"headerName": "013", "field": "Ending Backlog 013", "editable": True},
            {"headerName": "014C", "field": "Ending Backlog 014C", "editable": True},
        ],
    },
]

for d in dates:
    column_defs.append({
        "headerName": str(d.date()),
        "children": [
            {"headerName": "013", "field": f"{d.date()} 013", "editable": True},
            {"headerName": "014C", "field": f"{d.date()} 014C", "editable": True},
        ]
    })

grid_options = {
    "columnDefs": column_defs,
    "defaultColDef": {"resizable": True, "sortable": False, "filter": False, "minWidth": 90},
    "animateRows": True,
}

# ========== DISPLAY GRID ==========
st.subheader("Daily Report Plan (Ending 014C & 013)")
grid_response = AgGrid(
    df,
    gridOptions=grid_options,
    theme="streamlit",
    update_mode=GridUpdateMode.MODEL_CHANGED,
    data_return_mode=DataReturnMode.AS_INPUT,
    fit_columns_on_grid_load=True,
    height=400,
)

st.set_page_config(layout="wide")
edited_df = pd.DataFrame(grid_response["data"])

# ========== SAVE + CLEAR TABLE ==========
if st.button("Save Changes"):
    try:
        # Add audit columns
        edited_df["SavedAt"] = datetime.now()
        edited_df["SavedBy"] = st.session_state.get("username", "Anonymous")

        # Append to SQL Server
        edited_df.to_sql("DailyReport_014C_013_End", engine, if_exists="replace", index=False)

        # Clear the table after saving to avoid duplication
        # st.success("✅ Data appended to SQL Server successfully! Table cleared for new input.")
        st.session_state["data"] = create_empty_table()  # Reset the grid
        st.rerun()  # Reload the app (show cleared table)
    except Exception as e:
        st.error(f"❌ Error saving data: {e}")