import streamlit as st
import pandas as pd
from datetime import datetime
from st_aggrid import AgGrid
from st_aggrid.shared import GridUpdateMode, DataReturnMode
from sqlalchemy import create_engine, text
import urllib
from database.dbcon import fetch_data
from calendar import monthrange

# =========================================
# DATABASE CONNECTION
# =========================================
server = r"172.17.225.13"
database = "iPAR"
username = "sa"
password = "s@p@33"

params = urllib.parse.quote_plus(
    f"DRIVER={{ODBC Driver 17 for SQL Server}};"
    f"SERVER={server};DATABASE={database};"
    f"UID={username};PWD={password};"
    "Trusted_Connection=no;"
)
engine = create_engine(f"mssql+pyodbc:///?odbc_connect={params}")

# =========================================
# PAGE SETTINGS
# =========================================
st.set_page_config(layout="wide")
st.title("📊 Daily Report Plan (Beginning 014C & 013)")

# =========================================
# USER SESSION
# =========================================
st.sidebar.header("👤 User Info")
saved_by = st.sidebar.text_input("Enter your name:", "Anonymous")

# =========================================
# MONTH SELECTION
# =========================================
st.sidebar.header("📅 Select Month")
selected_year = st.sidebar.number_input(
    "Year", min_value=2020, max_value=2100, value=datetime.now().year
)
selected_month = st.sidebar.selectbox(
    "Month", range(1, 13), index=datetime.now().month - 1
)

num_days = monthrange(selected_year, selected_month)[1]
dates = [datetime(selected_year, selected_month, d) for d in range(1, num_days + 1)]

# =========================================
# FETCH LINE MASTER
# =========================================
x = fetch_data("SELECT CustomerLine FROM LineMaster")["CustomerLine"].tolist()

# =========================================
# CREATE EMPTY STRUCTURE
# =========================================
def create_empty_table():
    data = {
        "Line Name Master": x,
        "Beginning Backlog 013": [None for _ in x],
        "Beginning Backlog 014C": [None for _ in x],
    }
    for d in dates:
        data[f"{d.date()} 013"] = [None for _ in x]
        data[f"{d.date()} 014C"] = [None for _ in x]
    return pd.DataFrame(data)

# =========================================
# LOAD OR INITIALIZE SQL DATA
# =========================================
try:
    df = pd.read_sql("SELECT * FROM DailyReport_014C_013_Beg", engine)
except Exception:
    df = pd.DataFrame()

base_df = create_empty_table()
if df.empty:
    df = base_df.copy()
else:
    existing_lines = (
        df["Line Name Master"].tolist() if "Line Name Master" in df.columns else []
    )
    new_lines = [line for line in x if line not in existing_lines]
    if new_lines:
        new_rows = base_df[base_df["Line Name Master"].isin(new_lines)]
        df = pd.concat([df, new_rows], ignore_index=True)

# =========================================
# DEFINE GRID COLUMNS
# =========================================
column_defs = [
    {
        "headerName": "Line Name Master",
        "field": "Line Name Master",
        "editable": False,
        "pinned": "left",
        "wrapText": True,
        "autoHeight": True,
    },
    {
        "headerName": "Beginning Backlog",
        "pinned": "left",
        "children": [
            {"headerName": "013", "field": "Beginning Backlog 013", "editable": True},
            {"headerName": "014C", "field": "Beginning Backlog 014C", "editable": True},
        ],
    },
]

for d in dates:
    column_defs.append(
        {
            "headerName": str(d.date()),
            "children": [
                {"headerName": "013", "field": f"{d.date()} 013", "editable": True},
                {"headerName": "014C", "field": f"{d.date()} 014C", "editable": True},
            ],
        }
    )

grid_options = {
    "columnDefs": column_defs,
    "defaultColDef": {
        "resizable": True,
        "sortable": False,
        "filter": False,
        "minWidth": 90,
    },
    "animateRows": True,
}

# =========================================
# DISPLAY GRID
# =========================================
grid_response = AgGrid(
    df,
    gridOptions=grid_options,
    theme="streamlit",
    update_mode=GridUpdateMode.VALUE_CHANGED,
    data_return_mode=DataReturnMode.AS_INPUT,
    fit_columns_on_grid_load=True,
    height=550,
)
edited_df = pd.DataFrame(grid_response["data"])

# =========================================
# SESSION MANAGEMENT
# =========================================
if "original_df" not in st.session_state:
    st.session_state["original_df"] = df.copy()

edited_df = edited_df.set_index("Line Name Master")
original_df = st.session_state["original_df"].set_index("Line Name Master")

protected_cols = {"Month", "Year", "SavedAt", "SavedBy"}

changed_cells = []
for line in edited_df.index:
    for col in edited_df.columns:
        if col in protected_cols:
            continue
        new_val = edited_df.at[line, col]
        old_val = (
            original_df.at[line, col]
            if line in original_df.index and col in original_df.columns
            else None
        )
        if (pd.isna(new_val) and pd.isna(old_val)) or (new_val == old_val):
            continue
        changed_cells.append((line, col, new_val))

# =========================================
# SAVE CHANGES TO SQL (Instant, No Flicker)
# =========================================
if changed_cells:
    try:
        with engine.begin() as conn:
            for line_name, col, val in changed_cells:
                update_query = text(f"""
                    UPDATE DailyReport_014C_013_Beg
                    SET [{col}] = :val,
                        SavedAt = :now,
                        SavedBy = :user,
                        Month = :month,
                        Year = :year
                    WHERE [Line Name Master] = :line
                """)
                result = conn.execute(
                    update_query,
                    {
                        "val": val,
                        "now": datetime.now(),
                        "user": saved_by,
                        "month": selected_month,
                        "year": selected_year,
                        "line": line_name,
                    },
                )

                if result.rowcount == 0:
                    insert_query = text(f"""
                        INSERT INTO DailyReport_014C_013_Beg 
                        ([Line Name Master], [{col}], SavedAt, SavedBy, Month, Year)
                        VALUES (:line, :val, :now, :user, :month, :year)
                    """)
                    conn.execute(
                        insert_query,
                        {
                            "val": val,
                            "now": datetime.now(),
                            "user": saved_by,
                            "month": selected_month,
                            "year": selected_year,
                            "line": line_name,
                        },
                    )

        # ✅ Update local session copy (no rerun needed)
        for line_name, col, val in changed_cells:
            st.session_state["original_df"].loc[line_name, col] = val

        st.toast(f"✅ Saved by {saved_by}", icon="💾")

    except Exception as e:
        st.error(f"❌ Error saving change: {e}")

# =========================================
# EXPORT OPTION
# =========================================
st.download_button(
    label="📤 Export Current Data to CSV",
    data=edited_df.reset_index().to_csv(index=False).encode("utf-8"),
    file_name=f"DailyReport_{selected_year}_{selected_month:02d}.csv",
    mime="text/csv",
)
