import pyodbc
import pandas as pd


def get_connection():

    connstr = (
        "DRIVER={ODBC Driver 17 for SQL Server};"
        "SERVER=172.17.225.13;"
        "DATABASE=iPAR;"
        "UID=sa;"
        "PWD=s@p@33"
    )

    return pyodbc.connect(connstr)


def fetch_data(query : str, params=None):
    
    with get_connection() as con:
        return pd.read_sql(sql=query, con=con, params=params)

def execute_stored_procedure(query: str, params: list):
    placeholders = ', '.join(['?'] * len(params))
    with get_connection() as con:
        with con.cursor() as cursor:
            result = cursor.execute(f"EXEC {query} {placeholders}", params)
            cursor.commit()
            return result