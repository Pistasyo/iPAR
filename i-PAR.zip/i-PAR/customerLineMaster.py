import streamlit as st
import pandas as pd
import pyodbc
from streamlit_searchbox import st_searchbox 
st.set_page_config(layout="wide")

# Database connection parameters
DB_CONFIG = {
    "driver": "ODBC Driver 17 for SQL Server",
    "server": "172.17.225.13",
    "database": "iPAR",
    "uid": "sa",
    "pwd": "s@p@33"
}

def get_connection():
    """Create and return a new database connection."""
    conn_str = (
        f"DRIVER={{{DB_CONFIG['driver']}}};"
        f"SERVER={DB_CONFIG['server']};"
        f"DATABASE={DB_CONFIG['database']};"
        f"UID={DB_CONFIG['uid']};"
        f"PWD={DB_CONFIG['pwd']}"
    )
    return pyodbc.connect(conn_str)

def fetch_data(query, params=None):
    """Fetch data from the database into a DataFrame."""
    with get_connection() as conn:
        return pd.read_sql(query, conn, params=params)

def execute_stored_procedure_with_params(proc_name, params):
    """Execute a stored procedure with parameters."""
    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(f"EXEC {proc_name} ?, ?, ?, ?, ?, ?", params)
            conn.commit()

def execute_stored_procedure(proc_name, params):
    """Execute a stored procedure with parameters."""
    with get_connection() as conn:
        return pd.read_sql(proc_name, params=params, con=conn)  

def main():
    st.title("Customer Line Master")
    # Date inputs side by side

    # Fetch and display data
    try:
        # df_line = execute_stored_procedure("dbo.upSelectData ?", "SelectLineCode")
        # df_linename = execute_stored_procedure("dbo.upCustomerLine ?", "SelectLine")
        # df_linename = execute_stored_procedure("dbo.upSelectData ?", "Select")
        df_linemaster = execute_stored_procedure("dbo.upCustomerLine ?", "Select")
    except Exception as e:
        st.error(f"Failed to fetch data: {e}")
        return

    left_col, mid_col = st.columns([1, 3])
    st.write("\n")
    with left_col:
        # productNo = st.selectbox("Product No", df_prod, placeholder="Enter product no")
        # lineCode = st.selectbox("Line Code", df_linename, placeholder="Enter Line code")
        customerCode = st.text_input("Customer Code")
        customerLineName = st.text_input("Customer Line Name")
        Description = st.text_input("Description")
        IsEnabled = st.checkbox("Is Enabled") 

    st.set_page_config(layout="wide")
    st.dataframe(df_linemaster, hide_index=True)
    # left_col, mid_col = st.columns([1,3])
    # with left_col:
    submit = st.button("Submit")
        # delete = st.button("Delete")

    if submit:
        # lineCode, lineName = str.split(lineCode, ":")
        execute_stored_procedure_with_params("dbo.upCustomerLine", params=("Add", "",customerCode, customerLineName, Description, IsEnabled))

    # df_linemaster = execute_stored_procedure("dbo.upCustomerLine ?", "SelectLineMaster")

if __name__ == "__main__":
    main()