import streamlit as st

# Hide Streamlit menu and footer
hide_streamlit_style = """
<style>
#MainMenu {visibility: hidden;}
footer {visibility: hidden;}
</style>
"""
st.set_page_config(layout="wide")
st.markdown(hide_streamlit_style, unsafe_allow_html=True)
# Initialize session state
if "role" not in st.session_state:
    st.session_state.role = None

# App setup
ROLES = ["Planner"]

def login():
    st.header("Log in")
    role = st.selectbox("Choose your role", ROLES)
    if st.button("Log in"):
        st.session_state.role = role
        st.rerun()

def logout():
    st.session_state.role = None
    st.rerun()

# Current role
role = st.session_state.role

# Define pages
logout_page = st.Page(logout, title="Log out", icon=":material/logout:")

request_1 = st.Page(
    "plan.py",
    title="Plan",
    icon=":material/settings:",
    default=(role == "Planner"),
)
request_2 = st.Page(
    "actual.py",
    title="Actual",
    icon=":material/settings:"
)

dailyReport_01 = st.Page(
    "dailyreport.py",
    title="Daily Report Beginning (Plan)",
    icon=":material/settings:"
)

dailyReport_02 = st.Page(
    "dailyreport02.py",
    title="Daily Report Ending (Plan)",
    icon=":material/settings:"
)

# dailyReport_03 = st.Page(
#     "dailyreport.py",
#     title="Daily Report 016C (Plan)",
#     icon=":material/settings:"
# )

maintenance_1 = st.Page(
    "customerLineMaster.py",
    title="Customer Master",
    icon=":material/settings:"
)

maintenance_2 = st.Page(
    "linemaster.py",
    title="Line Master",
    icon=":material/settings:"
)

# ✅ Correctly define nested pages as lists, not dicts
daily_report_pages = [dailyReport_01, dailyReport_02]

# Group pages
account_pages = [logout_page]
request_pages = [request_1, request_2]
maintenance_pages = [maintenance_1, maintenance_2]
dailyreport_pages = [dailyReport_01, dailyReport_02]

# App title
st.title("i-PAR (Plan Vs Actual Result)")

# Navigation setup
page_dict = {}
if st.session_state.role in ["Planner"]:
    page_dict["Maintenance"] = maintenance_pages
    page_dict["Result"] = request_pages
    page_dict["Daily Report"] = dailyreport_pages

# ✅ st.navigation expects lists or dicts of st.Page objects
if len(page_dict) > 0:
    pg = st.navigation({"Account": account_pages} | page_dict)
else:
    pg = st.navigation([st.Page(login)])

pg.run()
