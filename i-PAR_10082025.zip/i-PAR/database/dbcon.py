import pyodbc
import pandas as pd


def get_connection():

    connstr = (
        "DRIVER={ODBC Driver 17 for SQL Server};"
        "SERVER=localhost\\SQLExpress;"
        "DATABASE=iPAR;"
        "UID=ipar_user;"
        "PWD=ipar_user01"
    )

    return pyodbc.connect(connstr)


def fetch_data(query : str, params=None):
    
    with get_connection() as con:
        return pd.read_sql(sql=query, con=con, params=params)

def execute_stored_procedure(query: str, params: list):
    placeholders = ', '.join(['?'] * len(params))
    with get_connection() as con:
        with con.cursor() as cursor:
            result = cursor.execute(f"EXEC {query} {placeholders}", params)
            cursor.commit()
            return result