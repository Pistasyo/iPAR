import streamlit as st
import pandas as pd
from datetime import datetime
from st_aggrid import AgGrid
from st_aggrid.shared import GridUpdateMode, DataReturnMode
from sqlalchemy import create_engine, text
import urllib
from database.dbcon import fetch_data
from calendar import monthrange

# =========================================
# DATABASE CONNECTION
# =========================================
server = "localhost\\SQLExpress"
database = "iPAR"
username = "ipar_user"
password = "ipar_user01"

params = urllib.parse.quote_plus(
    f"DRIVER={{ODBC Driver 17 for SQL Server}};"
    f"SERVER={server};DATABASE={database};"
    f"UID={username};PWD={password};"
    "Trusted_Connection=no;"
)
engine = create_engine(f"mssql+pyodbc:///?odbc_connect={params}")

# =========================================
# PAGE SETTINGS
# =========================================
st.title("📊 Daily Report Plan (Beginning 014C & 013)")

# =========================================
# USER SESSION
# =========================================
st.sidebar.header("👤 User Info")
saved_by = st.sidebar.text_input("Enter your name:", "Anonymous")

# =========================================
# MONTH SELECTION
# =========================================
st.sidebar.header("📅 Select Month")
selected_year = st.sidebar.number_input("Year", 2020, 2100, datetime.now().year)
selected_month = st.sidebar.selectbox(
    "Month", range(1, 13), index=datetime.now().month - 1
)
num_days = monthrange(selected_year, selected_month)[1]
dates = [datetime(selected_year, selected_month, d) for d in range(1, num_days + 1)]

# =========================================
# FETCH LINE MASTER
# =========================================
x = fetch_data("SELECT CustomerLine FROM LineMaster")["CustomerLine"].tolist()

# =========================================
# CREATE EMPTY STRUCTURE
# =========================================
def create_empty_table():
    data = {
        "Line Name Master": x,
        "Beginning Backlog 013": [None for _ in x],
        "Beginning Backlog 014C": [None for _ in x],
    }
    for d in dates:
        data[f"{d.date()} 013"] = [None for _ in x]
        data[f"{d.date()} 014C"] = [None for _ in x]
    return pd.DataFrame(data)

# =========================================
# LOAD SQL DATA
# =========================================
try:
    df = pd.read_sql("SELECT * FROM DailyReport_014C_013_Beg", engine)
except Exception:
    df = pd.DataFrame()

# Drop ID column if exists
if "ID" in df.columns:
    df = df.drop(columns=["ID"])

base_df = create_empty_table()

if df.empty:
    df = base_df.copy()
else:
    existing_lines = df["Line Name Master"].tolist() if "Line Name Master" in df.columns else []
    new_lines = [line for line in x if line not in existing_lines]
    if new_lines:
        new_rows = base_df[base_df["Line Name Master"].isin(new_lines)]
        df = pd.concat([df, new_rows], ignore_index=True)

# =========================================
# DEFINE GRID
# =========================================
column_defs = [
    {
        "headerName": "Line Name Master",
        "field": "Line Name Master",
        "editable": False,
        "pinned": "left",
        "wrapText": True,
        "autoHeight": True,
    },
    {
        "headerName": "Beginning Backlog",
        "pinned": "left",
        "children": [
            {"headerName": "013", "field": "Beginning Backlog 013", "editable": True},
            {"headerName": "014C", "field": "Beginning Backlog 014C", "editable": True},
        ],
    },
]

# Daily columns
for d in dates:
    column_defs.append(
        {
            "headerName": str(d.date()),
            "children": [
                {"headerName": "013", "field": f"{d.date()} 013", "editable": True},
                {"headerName": "014C", "field": f"{d.date()} 014C", "editable": True},
            ],
        }
    )

# Live totals using valueGetter
total_013_expr = " + ".join([f"Number(data['Beginning Backlog 013'])"] + [f"Number(data['{d.date()} 013'])" for d in dates])
total_014c_expr = " + ".join([f"Number(data['Beginning Backlog 014C'])"] + [f"Number(data['{d.date()} 014C'])" for d in dates])

column_defs += [
    {
        "headerName": "Total 013",
        "field": "Total 013",
        "editable": False,
        "valueGetter": total_013_expr,
    },
    {
        "headerName": "Total 014C",
        "field": "Total 014C",
        "editable": False,
        "valueGetter": total_014c_expr,
    },
]

grid_options = {
    "columnDefs": column_defs,
    "defaultColDef": {"resizable": True, "sortable": False, "filter": False, "minWidth": 90},
    "animateRows": True,
}

# =========================================
# DISPLAY GRID
# =========================================
grid_response = AgGrid(
    df,
    gridOptions=grid_options,
    theme="streamlit",
    update_mode=GridUpdateMode.VALUE_CHANGED,  # recalculates on edit
    data_return_mode=DataReturnMode.AS_INPUT,
    fit_columns_on_grid_load=True,
    height=600,
)

# =========================================
# CLEAN AND PREPARE DATA FOR SAVE
# =========================================
edited_df = pd.DataFrame(grid_response["data"])
edited_df = edited_df.loc[:, ~edited_df.columns.str.startswith("::")]  # drop internal cols

# Drop totals only if they exist (safe)
save_df = edited_df.drop(columns=[c for c in ["Total 013", "Total 014C"] if c in edited_df.columns])
edited_idx = save_df.set_index("Line Name Master")

if "original_df" not in st.session_state:
    st.session_state["original_df"] = edited_idx.copy()

original_idx = st.session_state["original_df"]

# =========================================
# SAVE & EXPORT CONTROLS
# =========================================
col1, col2 = st.columns([1, 1])
with col1:
    save_btn = st.button("💾 Save Changes to Database", use_container_width=True)
with col2:
    st.download_button(
        label="📤 Export Current Data to CSV",
        data=edited_df.to_csv(index=False).encode("utf-8"),
        file_name=f"DailyReport_{selected_year}_{selected_month:02d}.csv",
        mime="text/csv",
        use_container_width=True,
    )

# =========================================
# SAVE FUNCTIONALITY
# =========================================
if save_btn:
    protected_cols = {"ID", "Month", "Year", "SavedAt", "SavedBy"}
    changed_cells = []
    for line in edited_idx.index:
        for col in edited_idx.columns:
            if col in protected_cols:
                continue
            new_val = edited_idx.at[line, col]
            old_val = (
                original_idx.at[line, col]
                if (line in original_idx.index and col in original_idx.columns)
                else None
            )
            if (pd.isna(new_val) and pd.isna(old_val)) or (new_val == old_val):
                continue
            changed_cells.append((line, col, new_val))

    if not changed_cells:
        st.info("No changes detected.")
    else:
        try:
            with engine.begin() as conn:
                for line_name, col, val in changed_cells:
                    if val in [None, ""]:
                        val_to_save = None
                    else:
                        try:
                            val_to_save = float(val)
                        except (ValueError, TypeError):
                            val_to_save = val

                    # Ensure row exists
                    conn.execute(
                        text("""
                            IF NOT EXISTS (
                                SELECT 1 FROM DailyReport_014C_013_Beg
                                WHERE [Line Name Master] = :line
                                  AND [Month] = :month
                                  AND [Year] = :year
                            )
                            INSERT INTO DailyReport_014C_013_Beg
                            ([Line Name Master], [Month], [Year], [SavedAt], [SavedBy])
                            VALUES (:line, :month, :year, :now, :user)
                        """),
                        {
                            "line": line_name,
                            "month": selected_month,
                            "year": selected_year,
                            "now": datetime.now(),
                            "user": saved_by,
                        },
                    )

                    # Update cell
                    conn.execute(
                        text(f"""
                            UPDATE DailyReport_014C_013_Beg
                            SET [{col}] = :val,
                                [SavedAt] = :now,
                                [SavedBy] = :user
                            WHERE [Line Name Master] = :line
                              AND [Month] = :month
                              AND [Year] = :year
                        """),
                        {
                            "val": val_to_save,
                            "now": datetime.now(),
                            "user": saved_by,
                            "month": selected_month,
                            "year": selected_year,
                            "line": line_name,
                        },
                    )

            # Update session copy
            st.session_state["original_df"] = edited_idx.copy()
            st.success("✅ Changes saved successfully!")

        except Exception as e:
            st.error(f"❌ Error saving changes: {e}")
