import pyodbc

server = r"172.17.225.13"  # 👈 change to your actual instance
database = "iPAR"
username = "sa"
password = "s@p@33"

conn_str = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    f"SERVER={server};DATABASE={database};"
    f"UID={username};PWD={password};"
    "Trusted_Connection=no;"
)
try:
    conn = pyodbc.connect(conn_str)
    print("✅ Connection successful!")
except Exception as e:
    print("❌ Error:", e)